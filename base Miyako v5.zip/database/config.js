module.exports = {
  tokens: "8576888349:AAGKD0tHnFcQuNA1eUZhGTaHdqsq0itkL9w",  // Ubah Jadi Token Bot Mu !!!
  owner: "8799225142", // Ubah Jadi Id Mu !!!
  port: "25666", // Ubah Jadi Port Panel Mu !!!
  ipvps: "http://gixsz.cloudpanellvip.biz.id" // Ubah Jadi Ip Vps Mu !!!
};